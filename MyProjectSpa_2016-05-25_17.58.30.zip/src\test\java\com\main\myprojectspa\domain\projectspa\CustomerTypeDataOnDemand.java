package com.main.myprojectspa.domain.projectspa;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = CustomerType.class)
public class CustomerTypeDataOnDemand {
}
