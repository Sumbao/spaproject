package com.main.myprojectspa.domain.projectspa;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = MassageTypes.class)
public class MassageTypesIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
