package com.main.myprojectspa.domain.projectspa;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Customer.class)
public class CustomerIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
