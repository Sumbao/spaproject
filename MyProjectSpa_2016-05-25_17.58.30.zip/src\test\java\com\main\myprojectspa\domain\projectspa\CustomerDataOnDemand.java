package com.main.myprojectspa.domain.projectspa;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Customer.class)
public class CustomerDataOnDemand {
}
