package com.main.myprojectspa.domain.projectspa;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = MassageTypes.class)
public class MassageTypesDataOnDemand {
}
