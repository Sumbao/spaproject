package com.main.myprojectspa.domain.projectspa;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Massage.class)
public class MassageIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
