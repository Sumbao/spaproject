/**
 * Created by zazabi37 on 25/02/2016.
 */


$("#btn_loginmain").on('click',function(){
    window.location = "/MyProjectSpa/login";
});


