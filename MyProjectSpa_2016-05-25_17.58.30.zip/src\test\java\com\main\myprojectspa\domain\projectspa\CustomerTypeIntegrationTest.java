package com.main.myprojectspa.domain.projectspa;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = CustomerType.class)
public class CustomerTypeIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
