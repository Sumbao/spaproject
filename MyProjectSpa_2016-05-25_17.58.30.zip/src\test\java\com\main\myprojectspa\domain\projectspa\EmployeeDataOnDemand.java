package com.main.myprojectspa.domain.projectspa;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Employee.class)
public class EmployeeDataOnDemand {
}
